# Svenska Call Translator — Android v0.2

Android Studio starter for **Swedish (`sv-SE`) speech → English (`en-US`)**.

## v0.2 features
- Floating overlay above other apps.
- Microphone foreground service with ongoing notification and Stop action.
- Foreground listening/restart loop and partial Swedish captions.
- Swedish → English on-device translation through Google ML Kit.
- English text-to-speech.
- Explicit overlay and microphone permission flow.

## Install
1. Open this folder in Android Studio.
2. Use JDK 17 and install Android SDK Platform 35.
3. Sync Gradle and run `app` on an Android 8.0+ phone.
4. Tap **Enable floating translator**.
5. Allow **Display over other apps** and microphone access.
6. Start a call, enable speakerphone, return to the translator and tap **Listen**.

## Call-audio limitation
The overlay can display above another app, but it cannot bypass Android's call-audio privacy protections. A normal third-party app cannot directly read the private incoming audio stream from cellular, Discord, or Snapchat calls. The foreground service listens to the microphone input Android grants it. While a call app owns the microphone, Android or the device vendor may block, mute, or change microphone access. It cannot guarantee hearing the other caller on every phone or app. A second device near the call speaker is the most reliable workaround if simultaneous microphone access is blocked.

The Speak English button plays through the phone's normal audio output; it does not inject translated speech into the active call. No call recording is saved. Get the other participant's knowledge and consent before translating a conversation.

## Production QA still needed
Test on the exact Android model and OS version for cellular, Discord, and Snapchat. This source project has not been compiled into an APK in this environment.


## Build an APK without installing Android Studio locally
A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. Upload this project to a GitHub repository, open **Actions**, select **Android APK build**, and choose **Run workflow**. When the workflow succeeds, open its run and download the `svenska-call-translator-debug-apk` artifact. This builds a debug APK; it is for personal testing, not a Play Store release.
