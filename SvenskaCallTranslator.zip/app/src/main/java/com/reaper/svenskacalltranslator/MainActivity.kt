package com.reaper.svenskacalltranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private val requestCode = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "🇸🇪  SVENSKA  →  🇺🇸  ENGLISH"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "Live call translation companion"
            textSize = 16f
            setPadding(0, pad / 2, 0, pad)
        })
        status = TextView(this).apply {
            text = "Translate Swedish speech into English while keeping your call open."
            textSize = 15f
            setPadding(0, 0, 0, pad)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Enable floating translator"
            setOnClickListener { prepareAndStart() }
        })
        layout.addView(Button(this).apply {
            text = "Stop translator"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslatorOverlayService::class.java))
                status.text = "Translator stopped."
            }
        })
        layout.addView(TextView(this).apply {
            text = "HOW TO USE\n1. Start your phone, Discord, or Snapchat call.\n2. Put the call on speakerphone.\n3. Return here and enable the floating translator.\n4. Tap Listen on the floating panel.\n\nIMPORTANT\nAndroid normally blocks third-party apps from directly capturing another app's private call audio. This companion uses microphone input Android makes available. Some devices pause or restrict microphone access while another call app is active. If that happens, use a second device near the call speaker.\n\nThe English Speak button plays through your phone's normal audio output; it does not inject translated audio into the call. This app does not save recordings. Tell the other participant before translating a conversation."
            textSize = 14f
            setPadding(0, pad, 0, 0)
        })
        setContentView(layout)
    }

    private fun prepareAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Allow Display over other apps, then return and tap Enable again."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
            return
        }
        ContextCompat.startForegroundService(this,
            Intent(this, TranslatorOverlayService::class.java))
        status.text = "Translator running. Find the floating panel on your screen."
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            prepareAndStart()
        } else if (requestCode == this.requestCode) {
            status.text = "Microphone permission is required."
        }
    }
}
