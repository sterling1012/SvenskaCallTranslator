package com.reaper.svenskacalltranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class TranslatorOverlayService : Service(), android.speech.tts.TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var translator: Translator? = null
    private var tts: android.speech.tts.TextToSpeech? = null
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    private var statusView: TextView? = null
    private var sourceView: TextView? = null
    private var englishView: TextView? = null
    private var listenButton: Button? = null
    private var listening = false
    private var modelReady = false
    private var destroyed = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        tts = android.speech.tts.TextToSpeech(this, this)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(com.google.mlkit.nl.translate.TranslateLanguage.SWEDISH)
            .setTargetLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH)
            .build()
        translator = Translation.getClient(options)
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener {
                modelReady = true
                statusView?.text = "Ready • Swedish → English"
            }
            ?.addOnFailureListener {
                statusView?.text = "Model download failed. Check internet."
            }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(recognitionListener)
        } else {
            statusView?.text = "Speech recognition unavailable on this device."
        }
        showOverlay()
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val pad = (12 * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xEE17212B.toInt())
        }
        fun label(value: String, size: Float) = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(label("🇸🇪 Swedish → 🇺🇸 English", 16f))
        statusView = label("Downloading translation model…", 12f).apply {
            setTextColor(0xFFE5B82E.toInt())
            setPadding(0, pad / 2, 0, pad / 2)
        }
        sourceView = label("Swedish: waiting for speech", 14f)
        englishView = label("English: translation will appear here", 18f).apply {
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(statusView)
        root.addView(sourceView)
        root.addView(englishView)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listenButton = Button(this).apply {
            text = "Listen"
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        controls.addView(listenButton)
        controls.addView(Button(this).apply {
            text = "Speak English"
            setOnClickListener {
                val value = englishView?.text?.toString().orEmpty()
                    .removePrefix("English: ").trim()
                if (value.isNotBlank() && value != "translation will appear here") {
                    tts?.speak(value, android.speech.tts.TextToSpeech.QUEUE_FLUSH,
                        null, "english-translation")
                }
            }
        })
        controls.addView(Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        })
        root.addView(controls)
        panel = root

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            (340 * density).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (12 * density).toInt()
            y = (90 * density).toInt()
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager?.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        try {
            windowManager?.addView(root, params)
        } catch (e: Exception) {
            statusView?.text = "Overlay error: ${e.message}"
        }
    }

    private fun startListening() {
        if (recognizer == null) {
            statusView?.text = "Speech recognition unavailable."
            return
        }
        listening = true
        listenButton?.text = "Stop"
        statusView?.text = "Listening for Swedish…"
        beginRecognition()
    }

    private fun beginRecognition() {
        if (!listening || destroyed) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, TranslatorSettings.sourceLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, TranslatorSettings.sourceLocale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            statusView?.text = "Could not listen: ${e.message}"
            listening = false
            listenButton?.text = "Listen"
        }
    }

    private fun stopListening() {
        listening = false
        recognizer?.cancel()
        listenButton?.text = "Listen"
        statusView?.text = "Paused."
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { statusView?.text = "Listening for Swedish…" }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (listening && !destroyed) {
                statusView?.text = "Listening again…"
                handler.postDelayed({ beginRecognition() }, 500)
            }
        }
        override fun onResults(results: Bundle?) {
            val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!phrase.isNullOrBlank()) translatePhrase(phrase)
            if (listening && !destroyed) handler.postDelayed({ beginRecognition() }, 400)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!phrase.isNullOrBlank()) sourceView?.text = "Swedish: $phrase"
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun translatePhrase(phrase: String) {
        sourceView?.text = "Swedish: $phrase"
        if (!modelReady) {
            statusView?.text = "Translation model is still downloading."
            return
        }
        statusView?.text = "Translating…"
        translator?.translate(phrase)
            ?.addOnSuccessListener { english ->
                englishView?.text = "English: $english"
                statusView?.text = "Translation ready."
            }
            ?.addOnFailureListener { statusView?.text = "Translation failed. Try again." }
    }

    override fun onInit(status: Int) {
        if (status == android.speech.tts.TextToSpeech.SUCCESS) tts?.language = Locale.US
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Live translator",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, TranslatorOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Svenska Call Translator")
            .setContentText("Swedish → English microphone companion is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openApp).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        destroyed = true
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        translator?.close()
        tts?.shutdown()
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "svenska_translator"
        private const val NOTIFICATION_ID = 4107
        private const val ACTION_STOP = "com.reaper.svenskacalltranslator.STOP"
    }
}
