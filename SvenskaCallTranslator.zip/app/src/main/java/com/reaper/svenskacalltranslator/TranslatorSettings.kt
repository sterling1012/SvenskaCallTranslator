package com.reaper.svenskacalltranslator

object TranslatorSettings {
    const val sourceLocale = "sv-SE"
    const val targetLocale = "en-US"
}
