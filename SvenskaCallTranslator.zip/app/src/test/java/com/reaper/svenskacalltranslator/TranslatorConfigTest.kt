package com.reaper.svenskacalltranslator

import org.junit.Assert.assertEquals
import org.junit.Test

class TranslatorConfigTest {
    @Test fun sourceLanguageIsSwedish() {
        assertEquals("sv-SE", TranslatorSettings.sourceLocale)
    }

    @Test fun targetLanguageIsEnglish() {
        assertEquals("en-US", TranslatorSettings.targetLocale)
    }
}
